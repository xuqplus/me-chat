#define MAXPARAMSNUM 20

int get_sys_envs(char *envs, const char *delim_env, const char *delim_key, char *params_key[], char *env_name[], char * env_value[]);
